/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.&
 */

public class Starter {
    
	public static void main(String[] args) {
		/*JCanvas jc = new JCanvas();
        Dimension dim=new Dimension(1200,800);
        jc.setPreferredSize(dim);
        String s = "tarte";
        Peindre tableau = new Peindre(jc,s);
        JButton reload = new JButton("reload");
        jc.add(reload);

        MonThread monThread = new MonThread(tableau);

        tableau.go();
        tableau.reload();
        //monThread.start();

        if(!monThread.isAlive()){
            System.out.println("IL EST MOOOOOOOOOOOOORT");
        }
        reload.addActionListener(new EcouteurBoutonReload(tableau));

        MouseEvents me = new MouseEvents(tableau.getHisto(), jc);
        jc.addMouseListener(me);
        jc.addMouseMotionListener(me);*/

        Herbin herbinator_3000 = new Herbin();
        //herbinator_3000.herbinGenerator("abc", 1200, 800, false, false, false);//mot, w, h, avec bouton reload, avec souris, avec thread
        herbinator_3000.herbinGenerator(true, false);//souris, avec thread
		//Hand hand = new Hand();
		//HandsCapture hc = new HandsCapture();
		//HandsCapture.main(args);//Lance la kinect
		//hc.setHand(hand);
		//Herbin herbinator_3000 = new Herbin();
		//herbinator_3000.herbinGenerator("abc", 1200, 800, true, true, false);//mot, w, h, avec bouton reload, avec souris, avec thread
	}

}
