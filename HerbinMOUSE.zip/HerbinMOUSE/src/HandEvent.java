import java.util.ArrayList;

import Drawing.JShapeDraw;
import HandCapture.Hand;


public class HandEvent {

	private ArrayList<JShapeDraw> listeFormes;
	private JCanvas jc;
	private Hand hand;
	
	public HandEvent(ArrayList<JShapeDraw> lf, JCanvas jc, Hand h){
		this.listeFormes=lf;
		this.jc=jc;
		this.hand=h;
	}
}
