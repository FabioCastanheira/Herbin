//import HandCapture.HandsCapture;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.&
 */

/**
 *
 * @author ypierru
 */
public class StartRandomWithClass {
    
    public static void main(String[] args) {
            Herbin herbinator_3000 = new Herbin();
            herbinator_3000.herbinGenerator(true, false);//souris, avec thread
            //HandsCapture.main(args);
    }
}
