/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ypierru
 */
public class Constantes {

    public final static double APPARITION_TRIANGE = 0.90;
    public final static double APPARITION_DEMI = 0.01;
    public final static double APPARITION_CARRE = 0.01;
    public final static double APPARITION_CERCLE = 0.08;
    public final static int TRIANGLE=0;
    public final static int DEMI=3;
    public final static int CARRE=1;
    public final static int CERCLE=2;
    public final static int MARGE = 10;

    /******COULEURS*******/
       public final static int[] VIOLET={51,0,100};
       public final static int[] NUANCE_VIOLET={0,0,100};

       public final static int[] JAUNE={255,200,0};
       public final static int[] NUANCE_JAUNE={0,50,100};

       public final static int[] VERT={0,100,0};
       public final static int[] NUANCE_VERT={0,50,50};

       public final static int[] ROUGE={100,0,0};
       public final static int[] NUANCE_ROUGE={100,0,0};

       public final static int[] BLEU={0,0,200};
       public final static int[] NUANCE_BLEU={0,50,50};

       public final static int[] ORANGE={200,100,0};
       public final static int[] NUANCE_ORANGE={50,50,0};

}
